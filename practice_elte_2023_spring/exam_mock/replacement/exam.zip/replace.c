#include <stdio.h>
#include "replace.h"

void replace(char *string, Replacement_t *replacements, int length)
{
    return;
}

char *getReplaced(char *string, Replacement_t *replacements, int length)
{
    return NULL;
}